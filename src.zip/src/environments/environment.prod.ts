export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyAAyKY3KkG0l5LNzd1SDfOaF1FMpHWW0FA",
    authDomain: "streethook-d1b9a.firebaseapp.com",
    databaseURL: "https://streethook-d1b9a.firebaseio.com",
    projectId: "streethook-d1b9a",
    storageBucket: "streethook-d1b9a.appspot.com",
    messagingSenderId: "462416760955",
    appId: "1:462416760955:web:20980765f71edeefe292de"
  }
};

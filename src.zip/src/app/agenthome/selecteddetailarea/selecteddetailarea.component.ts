import { Component, OnInit } from '@angular/core';
import {SelecteddetailareaService } from "./selecteddetailarea.service";
import { Router, ActivatedRoute } from "@angular/router";
import { Location } from "@angular/common";
import {HttpService} from "../../http.service"
@Component({
  selector: 'app-selecteddetailarea',
  templateUrl: './selecteddetailarea.component.html',
  styleUrls: ['./selecteddetailarea.component.css']
})
export class SelecteddetailareaComponent implements OnInit {
  sub: any;
  Minamount: string;
  MaxAmount: string;
  ChainStatus: string;
  Conditions: string;
  Lookinpostcode: string;
  UserId: string;
  userDetail;
  username: any;
  email: any;
  Phone: any;


  constructor(public SelecteddetailareaService:SelecteddetailareaService,private route: ActivatedRoute,private _location: Location,public HttpService:HttpService) { }

  ngOnInit() {
    this.sub = this.route.paramMap.subscribe((params) => {
     
      this.Minamount = params.get("MinAmount");
      this.MaxAmount  = params.get("MaxAmount");
      this.ChainStatus = params.get("ChainStatus");
      this.Conditions  = params.get("Conditions");
      this.Lookinpostcode = params.get("Lookinpostcode");
      this.UserId  = params.get("UserId")
      console.log(this.UserId)
    });

    this.HttpService.getUsers(this.UserId).subscribe((data)=>{
      this.userDetail = data
     this.username = this.userDetail.username
     this.email = this.userDetail.email
     this.Phone = this.userDetail.Phone
    })
  }
  backClicked() {
    this._location.back();
  }
}

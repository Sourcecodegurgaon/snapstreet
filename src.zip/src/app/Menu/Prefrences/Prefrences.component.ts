import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Prefrences',
  templateUrl: './Prefrences.component.html',
  styleUrls: ['./Prefrences.component.css']
})
export class PrefrencesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from "@angular/core";
import { AuthService } from ".././auth.service";
import { AngularFireAuth } from "@angular/fire/auth";
import { Router, ActivatedRoute } from "@angular/router";
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
} from "@angular/router";
import { FormsService } from "../Home/Property/fillFormBuyer/fillFormBuyer.service";
import axios from 'axios';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import {StrapiAuthService} from "../strapi-auth.service";
import { first } from 'rxjs/operators'
@Component({
  selector: "app-template",
  templateUrl: "./template.component.html",
  styleUrls: ["./template.component.css"],
})
export class TemplateComponent implements OnInit {
  uid: any;
  selectedIndex = 0;
  maxNumberOfTabs = 2;
  isLoggedIn: Boolean = true;
  userData: any;
  boolean: boolean;
  isLoading: boolean = false;
  newUser: boolean = false;
  return: any;
  user: any;
  useremail: any;
  DOB: string;
  age: any;
  name: any;
  userPasswordRegister: any;
  model: any = {};
  loading = false;
  returnUrl: string;
  overlay: boolean = false;
  email: any;
  pass: any;
  displayName: any;
  userEmailRegister: any;
  password;
  emails: any;
  passs: any;
  now: Date = new Date();
  getUser: any;
  constructor(
    public authService: AuthService,
    public afAuth: AngularFireAuth,
    private route: ActivatedRoute,
    private router: Router,
    private FormService: FormsService,
    public HttpClient:HttpClient,
    public StrapiAuthService:StrapiAuthService
  ) {}

  ngOnInit() {
    this.userData = JSON.parse(sessionStorage.getItem('currentUser'));

if(this.userData != null)
{

  this.isLoggedIn = true;
}
else 
{
  this.isLoggedIn = false;
}

 
  }
  private LoggedIn() {
    this.user = JSON.parse(localStorage.getItem("user"));
    this.uid = this.user.uid;
    this.isLoggedIn = true;
  }
  private LoggedOut() {
    this.isLoggedIn = false;
  }

  facebookLogin() {
    this.isLoading = true;
    this.authService.FacebookAuth().then((data) => {
      this.user.Lastseen = this.now
      this.return = this.FormService.createUserTime(this.user)
        .then(data => {
        });
      this.isLoading = false;
    });
  }

  //SignIn Google
  googleLogin() {
    this.isLoading = true;
    this.authService.GoogleAuth().then((data) => {
      this.user.Lastseen = this.now
      this.return = this.FormService.createUserTime(this.user)
        .then(data => {
        });
      this.isLoading = false;
    });
  }

  //Signup Google
  googleSignup() {
    this.isLoading = true;
    this.authService.GoogleAuthSignup().then((data) => {
      this.user.Lastseen = this.now
      this.return = this.FormService.createUserTime(this.user)
        .then(data => {
        });
      this.isLoading = false;
    });
  }

  signIn(email, pass) {
    console.log(email + pass);
    this.isLoading = true;
    this.authService.SignIn(email, pass).then((data) => {
      this.isLoading = false;
      this.user.Lastseen = this.now
      this.return = this.FormService.createUserTime(this.user)
        .then(data => {
        });
      this.isLoading = false;
    });
  }

  NewUser() {
    this.newUser = true;
  }

  OldUser() {
    this.newUser = false;
  }
  close() {
    this.newUser = false;
    this.newUser = false;
  }

  signUp(displayName, email, pass) {
   console.log(displayName)
    this.overlay = true;
    this.authService.SignUp(email, pass).then((data) => {
      this.isLoading = false;
      this.user.Name = displayName;
      this.user.DOB = null;
      this.user.Phone = null;
      this.return = this.FormService.createUserCustomer(this.user).then(
        (data) => {
          this.user.Lastseen = this.now
          this.return = this.FormService.createUserTime(this.user)
            .then(data => {
            });
          console.log(data);
         
        }
      );
    });
  }

  userNew() {
    this.user.DOB = null;
    this.user.Phone = null;
    this.user.name;
    this.return = this.FormService.createUserCustomer(this.user).then(
      (data) => {
        console.log(data);
      }
    );
  }
  continueClose() {
    this.overlay = false;
  }

  keyDownFunction(event) {
    if (event.keyCode == 13) {
      this.signUp(this.name, this.email, this.password);
    }
  }
  
  saves() {
 
      this.signIn(this.emails, this.passs);
  
  }
  
  newUsers(displayName, email, pass)
  {
    axios
  .post('http://139.59.62.119:1337/auth/local/register', {
    username: displayName,
    email: email,
    password: pass,
  })
  .then(response => {
    // Handle success.
    console.log('Well done!');
    console.log('User profile', response.data.user);
    console.log('User token', response.data.jwt);

  })
  .catch(error => {
    // Handle error.
    console.log('An error occurred:', error.response);
  });
  }
  

  loggein(email,password)
  {
    this.isLoading = true;
    const data  = axios.post('http://139.59.62.119:1337/auth/local', {
    identifier: email,
    password: password
  }).then(response => {
    console.log('Well done!');
    console.log('User profile', response.data.user);
    console.log('User token', response.data);
    sessionStorage.setItem("user", JSON.stringify(response.data));}).catch(error => {console.log('An error occurred:', error.response);});
    this.isLoading = false
  }

  login(username, password) {


    // stop here if form is invalid
    // if (this.loginForm.invalid) {
    //     return;
    // }

    this.loading = true;
    this.StrapiAuthService.login(username,password)
        .pipe(first())
        .subscribe(
            data => {
              location.reload()
        
            },
            error => {
              if (error && error.error && error.error.message && error.error.message.length > 0) {
                alert(error.error.message[0].messages[0].message);
              }
              else 
              {
                alert('error');
              }
              
              //this.alertService.error(error);
              this.loading = false;
            });
}
}

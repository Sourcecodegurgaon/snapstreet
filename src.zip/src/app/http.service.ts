import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { listingBuyer } from './Model/listingBuyer';
import { map } from 'rxjs/operators';

export interface Config {
  Currentpostcode: string;
  Lookingpostcode: any;
  latitude: any;
  longitude: any;
  result:any;
}
@Injectable({
  providedIn: "root"
})
export class HttpService {
  headers: any;
  latUrl="https://api.postcodes.io/postcodes/"
  configUrl = "https://api-full.addressian.co.uk/postcode/";
  listingBuyer: any;

  
  constructor(private http: HttpClient) {

  }

  search(query: string): any {
    const headerDict = {
      "x-api-key": "BcLIABSb6J3HsvGTpI5jA8FrtOaQqR67736r1Hip"
    };

    const url = "https://api-full.addressian.co.uk/postcode/";
    return this.http.get(url + query, {
      headers: new HttpHeaders(headerDict)
    });
  }

 
getLat(Lookingpostcode) {

  return this.http.get(this.latUrl + Lookingpostcode);
 }

sentEmail(url,data)
{
  return this.http.post(url,data)
}

buyerEntries(UserId)
{
  return this.http.get<any>("http://139.59.62.119:1337/listing-buyers?&UserId=" + UserId)
}


sellerEntries(UserId)
{
  return this.http.get<any>("http://139.59.62.119:1337/listing-sellers?&UserId=" + UserId)
}

buyerMatches()
{
  return this.http.get<any>("http://139.59.62.119:1337/listing-sellers")
}
sellerMatches()
{
  return this.http.get<any>("http://139.59.62.119:1337/listing-buyers")
}

matchesBuyer(Lookingpostcode,Lookingstate,LookingTown,PropertyCondition,MaxAmount,LookingAddress,ownership,PropertyType,features,UserId,Maxrooms,Maxreception,PropertyFor,matchStatus,Maxbathrooms,MinAmount,myId)
{
  return this.http.post("http://139.59.62.119:1337/matches-buyers",{
    Lookingpostcode,Lookingstate,LookingTown,PropertyCondition,MaxAmount,LookingAddress,ownership,PropertyType,features,UserId,Maxrooms,Maxreception,PropertyFor,matchStatus,Maxbathrooms,MinAmount,myId
  })
}
matchesSeller(Lookingpostcode,LookingStreetname,PropertyType,Conditions,ChainStatus,FinancialPosition,MinAmount,MaxAmount,Validity,Type,Position,UserId,PropertyFor,matchStatus,myId,buyerId)
{
  return this.http.post("http://139.59.62.119:1337/matches-sellers",{
    Lookingpostcode,LookingStreetname,PropertyType,Conditions,ChainStatus,FinancialPosition,MinAmount,MaxAmount,Validity,Type,Position,UserId,PropertyFor,matchStatus,myId,buyerId
  })
}
matchesSellerSeller(Lookingpostcode,LookingStreetname,PropertyType,Conditions,ChainStatus,FinancialPosition,MinAmount,MaxAmount,Validity,Type,Position,UserId,PropertyFor,matchStatus,myId,Roomsmax,Ownership,Maxbathrooms,Maxreception,features)
{
  return this.http.post("http://139.59.62.119:1337/matches-sellers",{
    Lookingpostcode,LookingStreetname,PropertyType,Conditions,ChainStatus,FinancialPosition,MinAmount,MaxAmount,Validity,Type,Position,UserId,PropertyFor,matchStatus,myId,Roomsmax,Ownership,Maxbathrooms,Maxreception,features
  })
}



matchesSellerBuyer(Lookingpostcode,Lookingstate,LookingTown,PropertyCondition,MaxAmount,LookingAddress,ownership,PropertyType,features,UserId,Maxrooms,Maxreception,PropertyFor,matchStatus,Maxbathrooms,MinAmount,myId,Roomsmax,sellerId)
{
  return this.http.post("http://139.59.62.119:1337/matches-buyers",{
    Lookingpostcode,Lookingstate,LookingTown,PropertyCondition,MaxAmount,LookingAddress,ownership,PropertyType,features,UserId,Maxrooms,Maxreception,PropertyFor,matchStatus,Maxbathrooms,MinAmount,myId,Roomsmax,sellerId

  })
 
}




sellerEditing(id,Country,LookingAddress,LookingStreetname,LookingTown,Lookingpostcode,Lookingstate,MaxAmount,Maxbathrooms,Maxreception,PropertyCondition,PropertyFor,PropertyType,features,latitude,longitude,ownership,username,usertitle,UserId,Maxrooms,Currentpostcode,Currentstate,CurrentTowncity,Currentaddress)
{
 return this.http.put<any>("http://139.59.62.119:1337/listing-sellers/"+ id , {
  Country,LookingAddress,LookingStreetname,LookingTown,Lookingpostcode,
  Lookingstate,MaxAmount,Maxbathrooms,Maxreception,PropertyCondition,
   PropertyFor,PropertyType,features,latitude,
   longitude,ownership,username,usertitle,
   UserId,Maxrooms,Currentpostcode,Currentstate,CurrentTowncity,Currentaddress


 });
}

propertyId(propertyId,UserId,Type)
{
  return this.http.post<any>("http://139.59.62.119:1337/expressed-interests"  ,{
    propertyId,UserId,Type
  } )
}

getPropertyId()
{
  return this.http.get<any>("http://139.59.62.119:1337/expressed-interests")
}

postPropertyIdMatches(propertyId,UserId,Type)
{
  return this.http.post<any>("http://139.59.62.119:1337/expressmatches",{
    propertyId,UserId,Type
  })
}
getPropertyIdMatches()
{
  return this.http.get<any>("http://139.59.62.119:1337/expressmatches")
}

getMatchesBuyer()
{
   return this.http.get<any>("http://139.59.62.119/matches-buyers")
}
getMatchesSeller()
{
   return this.http.get<any>("http://139.59.62.119/matches-sellers")
}


getAgents()
{
  return this.http.get<any>("http://139.59.62.119/Agents")
}
getAgentsProfile(id)
{
  return this.http.get<any>("http://139.59.62.119:1337/Agents?&uid=" + id)
}
 putAgents(id,Fullname,Address,Postcode,Phonenumber,Jobtitle,SinglePercentage,Multipercentage)
 {
  return this.http.put("http://139.59.62.119:1337/Agents/" + id ,{Fullname,Address,Postcode,Phonenumber,Jobtitle,SinglePercentage,Multipercentage})

 }
 getagentByid(id)
 {
  return this.http.get<any>("http://139.59.62.119:1337/Agents/" + id)

 }



getNotification()
{
  return this.http.get<any>("http://139.59.62.119/notifications")

}

postNotification(id,Time,Type,UserId,Lastseen)
{
  return this.http.put<any>("http://139.59.62.119/notifications/" + id,{Time,Type,UserId,Lastseen})
}

createNotification(Time,Type,UserId)
{
  return this.http.post<any>("http://139.59.62.119:1337/notifications",{Time,Type,UserId})

}

postAgentBuyer(Lookinpostcode,ChainStatus,Roomsmax,PropertyCondition,Conditions,MinAmount,type,MaxAmount,UserId,uid)
{
  return this.http.post<any>("http://139.59.62.119/agentbuyers",{Lookinpostcode,ChainStatus,Roomsmax,PropertyCondition,Conditions,MinAmount,type,MaxAmount,UserId,uid})

}

postAgentSeller(LookingAddress,LookingTown,Lookingpostcode,Lookingstate,MaxAmount,Maxbathrooms,Maxbathroom,Maxreception,Roomsmax,PropertyCondition,PropertyType,UserId,features,ownership,uid)
{
  return this.http.post<any>("http://139.59.62.119/agent-sellers",{LookingAddress,LookingTown,Lookingpostcode,Lookingstate,MaxAmount,Maxbathrooms,Maxbathroom,Maxreception,Roomsmax,PropertyCondition,PropertyType,UserId,features,ownership,uid})
}

getagentBuyer()
{
  return this.http.get<any>("http://139.59.62.119/agentbuyers")

}
getagentSeller()
{
  return this.http.get<any>("http://139.59.62.119/agent-sellers")

}


getExpressedMatches(uid)
{
  return this.http.get<any>("http://139.59.62.119:1337/expressmatches?&UserId=" + uid)
}
getExpressedInterest(uid)
{
  return this.http.get<any>("http://139.59.62.119:1337/expressed-interests?&UserId=" + uid)
}

deleteAnBuyerEntry(id)
{
  return this.http.delete("http://139.59.62.119:1337/listing-buyers/" + id)
}
deleteAnSellerrEntry(id)
{
  return this.http.delete("http://139.59.62.119:1337/listing-sellers/" + id)
}

getUsers(id)
{
  return this.http.get("http://139.59.62.119:1337/Users/" + id)
}
editUsers(id,username,email,Phone,dob,CurrentAddress,prefrences)
{
  return this.http.put("http://139.59.62.119:1337/Users/" + id,{
    username,email,Phone,dob,CurrentAddress,prefrences
  })
}
addUsersDetails(id,username,email,Phone,dob,title)
{
  return this.http.put("http://139.59.62.119:1337/Users/" + id,{
    username,email,Phone,dob,title
  })
}

addUsersSellerDetails(id,username,email,Phone,dob,title,Currentpostcode,CurrentAddress,CurrentTown,Currentstate)
{
  return this.http.put("http://139.59.62.119:1337/Users/" + id,{
    username,email,Phone,dob,title,Currentpostcode,CurrentAddress,CurrentTown,Currentstate
  })
}

sellerProperties(id)
{
  return this.http.get<any>("http://139.59.62.119:1337/listing-sellers/" + id)
}
buyerProperties(id)
{
   return this.http.get<any>("http://139.59.62.119:1337/listing-buyers/" + id)
}

}
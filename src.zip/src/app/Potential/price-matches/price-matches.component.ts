import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-price-matches',
  templateUrl: './price-matches.component.html',
  styleUrls: ['./price-matches.component.css']
})
export class PriceMatchesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

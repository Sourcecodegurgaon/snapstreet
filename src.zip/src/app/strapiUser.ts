export interface StrapiUser {
    id: string;
    email: string;
    fullname: string;   
    confirmed: boolean;
 }
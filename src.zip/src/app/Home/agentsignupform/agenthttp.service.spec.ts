import { TestBed } from '@angular/core/testing';

import { AgenthttpService } from './agenthttp.service';

describe('AgenthttpService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AgenthttpService = TestBed.get(AgenthttpService);
    expect(service).toBeTruthy();
  });
});

import { Component, OnInit, ViewChild } from '@angular/core';
import { AngularFireAuth } from "@angular/fire/auth";
import { AuthService } from "../../auth.service";
import { AgentSignupService } from "../agentsignupform/agentSignup.service";
import { StateServiceService } from "./../../state-service.service";
import { agentSignup } from '../../Model/agentSignup';
import { AlertDialogAgentComponent } from "./alertDialogagent.component";
import {
  VERSION,
  MatDialogRef,
  MatDialog,
  MatSnackBar,
  MAT_DIALOG_DATA
} from "@angular/material";
import {
  AngularFireStorage,
  AngularFireUploadTask,
} from '@angular/fire/storage';
import { from, Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { map, startWith, take, ignoreElements } from "rxjs/operators";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Router, ActivatedRoute } from "@angular/router";
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
} from "@angular/router";
import { FormsService } from "../../Home/Property/fillFormBuyer/fillFormBuyer.service";
import axios from 'axios';
import { StrapiAuthService } from "../../strapi-auth.service";
import { first } from 'rxjs/operators'
@Component({
  selector: 'app-agentsignupform',
  templateUrl: './agentsignupform.component.html',
  styleUrls: ['./agentsignupform.component.css']
})
export class AgentsignupformComponent implements OnInit {
  @ViewChild('form') form;
  loggedIn: boolean = true
  userData: any;
 isLoading : boolean = false
  return: any;
  user: any;
  uid: any;
  newUser: boolean = true
  agentSignup: agentSignup = new agentSignup();
  users: any;
  ref: any;

  bytesTransferred: any
  uploadProgress: Observable<number>;
  image: any;
  hide = true;
  Type: string;
  verified: boolean = false;

  basePath = '/images';                       //  <<<<<<<
  downloadableURL: any;                      //  <<<<<<<
  task: any

  name: any;
  Name: any;
  email: any;
  password: any;
  fullname: any;
  filed: any;
  filles: any;
  requests;
  formsData: FormData;
  responseStrapi: any;
  constructor(public authService: AuthService,
    public afAuth: AngularFireAuth,
    private stateService: StateServiceService,
    public AgentSignupService: AgentSignupService,
    private dialog: MatDialog,
    private afStorage: AngularFireStorage,
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router,
    private FormService: FormsService,
    public StrapiAuthService: StrapiAuthService
  ) { }

  ngOnInit() {

    this.getUserDetail()


    this.http
      .get<any>("http://139.59.62.119:1337/Agents").subscribe((data) => { });



  }
  private LoggedIn() {
    this.loggedIn = true;

  }
  private LoggedOut() {
    this.loggedIn = false;

  }

  submitForm() {

    this.stateService.agentSignup = this.agentSignup;
    this.agentSignup.image = this.downloadableURL
    this.agentSignup.uid = this.uid
    this.return = this.AgentSignupService
      .createAgentCustomer(this.uid, this.agentSignup)
      .then(data => {
        if (data == true) {
          const dialogRef = this.dialog.open(
            AlertDialogAgentComponent,
            {
              data: {
                message: "HelloWorld",
                buttonText: {
                  cancel: "Done"
                }
              }
            }
          );
        }
      });
  }
  async upload(event) {
    this.isLoading = true
    const file = event.target.files[0];
    if (file) {
      const filePath = `${this.basePath}/${file.name}`;  // path at which image will be stored in the firebase storage
      this.task = this.afStorage.upload(filePath, file);    // upload task

      (await this.task).ref.getDownloadURL().then(url => { this.downloadableURL = url; });  // <<< url is found here
    }
    this.isLoading = false
  }




  facebookLogin() {
    this.isLoading = true;

    this.authService.FacebookAuth().then((data) => {
      this.isLoading = false;
    });
  }

  //SignIn Google
  googleLogin() {
    this.isLoading = true;
    this.authService.GoogleAuth().then((data) => {
      this.isLoading = false;
    });
  }


  getUserDetail() {
    this.user = JSON.parse(sessionStorage.getItem('currentUser'));
    if (this.user == null) {
      this.loggedIn = false
    }
    else {
      this.uid = this.user.id;
      this.loggedIn = true
      this.fullname = this.user.Username
      this.email = this.user.Email
    }

  }
  keyDownFunction(event) {
    if (event.keyCode == 13) {
      this.newUsers(this.name, this.email, this.password);
    }
  }


  strapi(fullname, company, postcode, address, jobtitle, phone, email, solefees, multiplefees) {
    this.isLoading = true
    this.responseStrapi = JSON.parse(this.requests.response)
    console.log(this.responseStrapi[0].url)
        this.http.post<any>("http://139.59.62.119:1337/Agents", {
      Fullname: fullname,
      Email: email,
      Phonenumber: phone,
      SinglePercentage: solefees,
      Multipercentage: multiplefees,
      Postcode: postcode,
      Companyname: company,
      Address: address,
      Jobtitle: jobtitle, uid: this.uid,Image:this.responseStrapi[0].url
    }).subscribe((data) => {
      this.isLoading = false
      this.router.navigate(["/Agenthome"]);
    });
  }
  chck(files) {
    this.http.post("http://139.59.62.119:1337/upload", { files: files }).subscribe((data) => {
    })

  }
  newUsers(displayName, email, pass) {
    axios
      .post('http://139.59.62.119:1337/auth/local/register', {
        username: displayName,
        email: email,
        password: pass
      })
      .then(response => {
        this.login(email, pass)

      })
      .catch(error => {
        // Handle error.
        console.log('An error occurred:', error.response);
      });
  }



  login(username, password) {
    this.isLoading = true;

    // stop here if form is invalid
    // if (this.loginForm.invalid) {
    //     return;
    // }

    this.StrapiAuthService.login(username, password)
      .pipe(first())
      .subscribe(
        data => {

          this.isLoading = false

          location.reload()
          this.LoggedIn()


        },
        error => {
          if (error && error.error && error.error.message && error.error.message.length > 0) {
            alert(error.error.message[0].messages[0].message);
            this.isLoading = false
          }
          else {
            alert('error');
            this.isLoading = false
          }

        });
  }
 


  postTheFileToStrapi2() {
    this.isLoading= true
    const formElement = this.form.nativeElement
    formElement.addEventListener('submit', e => {e.preventDefault();
      const request = new XMLHttpRequest();
      this.requests = request
      request.open('post', 'http://139.59.62.119:1337/upload');
      request.send(new FormData(formElement));
      this.isLoading= false
    });
 

  }
 

}

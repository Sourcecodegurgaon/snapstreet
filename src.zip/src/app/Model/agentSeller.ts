export class agentSeller {
LookingAddress: any
LookingTown: any
Lookingpostcode: any
Lookingstate: any
MaxAmount: any
Maxbathrooms:any
Maxbathroom: any
Maxreception:any
Roomsmax: any
PropertyCondition: any
PropertyType: any
UserId: any
features: any
ownership: any
}
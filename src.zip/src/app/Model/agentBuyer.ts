export class agentBuyer {
Lookingpostcode:any;
Lookingstate:any
LookingAddress:any
norooms:any
PropertyCondition:any
MaxAmount:any
PropertyType:any ;
ownership:any;
features:any;
propertyId:any
UserId:any
}
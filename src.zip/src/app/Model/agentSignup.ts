export class agentSignup {
    key: string;
    fullname: any;
    company:any;
    postcode:any;
    address:any
    jobtitle:any;
    phone:any;
    email:any;
    solefees:any;
    multiplefees:any;
    image:any;
    uid:any;
   active = true;
}
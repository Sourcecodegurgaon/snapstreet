export class notification{
time:any;
viewed:any;
userId:any;
Type:any;
propertyId:any;
}